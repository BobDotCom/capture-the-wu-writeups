<?php
// Database connection parameters
$servername = $_ENV['MYSQL_HOST'];
$username = $_ENV['MYSQL_USER'];
$password = $_ENV['MYSQL_PASSWORD'];
$dbname = $_ENV['MYSQL_DATABASE'];

// Get the submitted username and password
$user = $_POST['username'];
$pass = $_POST['password'];


// Create a new MySQLi object and establish the database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// // Prepare the SQL query using parameterized statements
// $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
// $stmt->bind_param("ss", $user, $pass);
// $stmt->execute();

// // Check if the query returned a matching row
// $result = $stmt->get_result();
// if ($result->num_rows === 1) {
//     // Login successful
//     echo "Login successful!";
// } else {
//     // Login failed
//     echo "Invalid username or password.";
// }


$sql = "SELECT * FROM users WHERE username = \"$user\" AND password = \"$pass\"";

try {
    $result = mysqli_query($conn, $sql);
} catch (Exception $e) {
    echo "<title>SQLi Error!</title>";
    echo 'Caught exception: ',  $e->getMessage(), "\n";
    echo '<p><a href="javascript:history.go(-1)" title="Return to previous page">« Go back</a></p>';
    exit();
}
if ($result->num_rows > 0) {
    echo "<title>SQLi Logged in!</title>";
    echo $sql;
    echo nl2br("\n");;
    // Iterate through the result set
    while ($row = $result->fetch_assoc()) {
        echo nl2br("id: " . $row["id"] . " - username: " . $row["username"] . " - password: " . $row["password"] . "\n");
    }
    echo nl2br("\n");;
    echo nl2br("Login successful!" . "\n" . "flag = fleg{uwu}");
    // Free the result set
    mysqli_free_result($result);
    echo '<p><a href="javascript:history.go(-1)" title="Return to previous page">« Go back</a></p>';
} else {
    // Handle the query error
    echo "<title>SQLi Login failed!</title>";
    echo $sql;
    echo nl2br("\n");;

    echo "invalid username or password";
    echo '<p><a href="javascript:history.go(-1)" title="Return to previous page">« Go back</a></p>';

}

// if ($result->fetch_all(MYSQLI_ASSOC) > 0) {
//     // Login successful
//     echo "Login successful!\n flag = fleg{uwu}";
// } else {
//     // Login failed
//     echo "Invalid username or password.";
// }

// Close the database connection
// $stmt->close();
$conn->close();
?>