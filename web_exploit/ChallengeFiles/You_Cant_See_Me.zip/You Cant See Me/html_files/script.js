// script.js

document.getElementById("login-form").addEventListener("submit", function(event) {
    event.preventDefault();
    
    // Get username and password input values
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    
    // Perform simple authentication check
    if (username == "admin" && password == "password") {
        // Successful login, redirect to dashboard or perform any desired action
        window.location.href = "dashboard.html";
    } else {
        // Invalid credentials, display error message
        document.getElementById("error-message").textContent = "Invalid username or password.";
    }
});
